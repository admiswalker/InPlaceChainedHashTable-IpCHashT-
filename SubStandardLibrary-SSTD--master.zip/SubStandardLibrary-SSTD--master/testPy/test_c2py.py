﻿def py_empty(): return;
def py_emptyArg(): print("* * * Welcome to sstd::c2py<T> ! * * *")

﻿#pragma once

#include <vector>


namespace sstd{
	template <class T> using  vec =             std::vector<T>;
	template <class T> using vvec = std::vector<std::vector<T>>;
}


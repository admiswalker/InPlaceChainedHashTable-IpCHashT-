﻿#pragma once
#include <string>

namespace sstd{
	void mkdir(const char*        pPath);
	void mkdir(const std::string&  path);
}

#pragma once

namespace sstd{
    int system(const        char* str);
    int system(const std::string& str);
}



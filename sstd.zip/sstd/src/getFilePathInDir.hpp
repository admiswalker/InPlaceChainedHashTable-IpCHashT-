﻿#pragma once

#include <vector>
#include <string>

namespace sstd{
	std::vector<std::string> getFilePathInDir(const char* DirAndFileName_withWildCard);
}

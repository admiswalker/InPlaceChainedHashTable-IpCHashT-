﻿#pragma once
#include <vector>
#include <string>

namespace sstd{
	std::vector<std::vector<std::string>> parseCSV(const char* pReadFile);
}

